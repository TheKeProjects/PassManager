import json
import os
import csv
from pathlib import Path
import hashlib
import tkinter as tk
from tkinter import ttk, simpledialog, messagebox, filedialog
from cryptography.fernet import Fernet
from datetime import datetime
import random
import string
import hmac
import pygame
import sys
import urllib.request
import tempfile
import subprocess
import webbrowser
import threading
import glob  # Para buscar archivos de changelog

# Obtener ruta de la carpeta Documentos
def get_documents_path():
    documents_path = os.path.join(os.path.expanduser('~'), 'Documents')
    passmanager_path = os.path.join(documents_path, 'PassManager')
  
    # Crear directorio si no existe
    if not os.path.exists(passmanager_path):
        os.makedirs(passmanager_path, exist_ok=True)
  
    return passmanager_path

#########################
# Configuración de archivos
#########################
APP_DATA_DIR = get_documents_path()
DATA_FILE = os.path.join(APP_DATA_DIR, "passwords.enc")
KEY_FILE = os.path.join(APP_DATA_DIR, "secret.key")
MASTER_FILE = os.path.join(APP_DATA_DIR, "master.key")
SETTINGS_FILE = os.path.join(APP_DATA_DIR, "settings.json")
VERSION_FILE = os.path.join(APP_DATA_DIR, "version.txt")
CHANGELOG_FILE = os.path.join(APP_DATA_DIR, "changelog.txt")  # Archivo para almacenar notas de versión

if getattr(sys, 'frozen', False):
    # Si está congelado (exe)
    BASE_DIR = sys._MEIPASS if hasattr(sys, '_MEIPASS') else os.path.dirname(sys.executable)
else:
    # Si está corriendo como script
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))

MUSIC_DIR = os.path.join(BASE_DIR)

# Obtener ruta absoluta de los archivos de música
def get_music_path(filename):
    current_dir = Path(os.path.dirname(os.path.abspath(__file__)))
    project_root = current_dir
    music_dir = project_root / 'musica'
    return os.path.join(music_dir, filename)

# URL del repositorio para actualizaciones
GITHUB_REPO = "https://raw.githubusercontent.com/TheKeProjects/PassManager/main/version.txt"
GITHUB_CHANGELOG = "https://raw.githubusercontent.com/TheKeProjects/PassManager/main/changelog.txt"
UPDATE_URL = "https://github.com/TheKeProjects/PassManager/releases/latest"

#########################
# Funciones auxiliares
#########################
def hash_master_password(password: str, salt: bytes = None):
    """Hashea la contraseña maestra con salt (si no existe, lo genera). Retorna salt + hash."""
    if salt is None:
        salt = os.urandom(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 100_000)
    return salt + dk

def verify_master_password(password: str, stored: bytes):
    """Verifica una contraseña maestra contra el valor almacenado (salt + hash)."""
    salt = stored[:16]
    dk = stored[16:]
    test_dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 100_000)
    return hmac.compare_digest(test_dk, dk)

def generate_random_password(length: int = 16):
    """Genera una contraseña segura aleatoria."""
    chars = string.ascii_letters + string.digits + string.punctuation
    return "".join(random.choice(chars) for _ in range(length))

def validate_password_strength(password: str):
    """Valida que la contraseña tenga al menos 8 caracteres, una letra y un dígito."""
    if len(password) < 8:
        return False
    has_letter = any(c.isalpha() for c in password)
    has_digit = any(c.isdigit() for c in password)
    return has_letter and has_digit

#########################
# Definición de temas
#########################
def get_theme_colors(theme_name):
    """Devuelve los colores para un tema específico"""
    themes = {
        "default": {
            "type": "gradient",
            "colors": [(255, 182, 193), (230, 200, 255), (255, 255, 255)],
            "button_bg": "#A7377C",
            "button_fg": "white",
            "label_fg": "black",
            "entry_bg": "white",
            "entry_fg": "black",
            "bg_color": "#FFFFFF",
            "action_btn_bg": "#DDDDDD",
            "action_btn_fg": "black",
            "delete_btn_bg": "#FF5555",
            "music": None,
            "history_bg": "#FFFFFF",
            "history_fg": "black"
        },
        "dark": {
            "type": "solid",
            "color": (40, 40, 40),
            "button_bg": "#333333",
            "button_fg": "#CCCCCC",
            "label_fg": "#FFFFFF",
            "entry_bg": "#222222",
            "entry_fg": "#FFFFFF",
            "bg_color": "#282828",
            "action_btn_bg": "#555555",
            "action_btn_fg": "#CCCCCC",
            "delete_btn_bg": "#992222",
            "music": None,
            "history_bg": "#222222",
            "history_fg": "#FFFFFF"
        },
        "purple": {
            "type": "gradient",
            "colors": [(150, 50, 200), (100, 0, 150), (70, 0, 100)],
            "button_bg": "#7D3C98",
            "button_fg": "white",
            "label_fg": "white",
            "entry_bg": "#4A235A",
            "entry_fg": "white",
            "bg_color": "#4A235A",
            "action_btn_bg": "#5D3C71",
            "action_btn_fg": "white",
            "delete_btn_bg": "#992266",
            "music": None,
            "history_bg": "#4A235A",
            "history_fg": "white"
        },
        # TEMAS DE VIDEOJUEGOS MEJORADOS
        "ultrakill": {
            "type": "gradient",
            "colors": [(200, 0, 0), (0, 0, 0), (100, 0, 0)],  # Rojo sangre, negro, rojo oscuro
            "button_bg": "#8B0000",   # Rojo oscuro
            "button_fg": "#FFD700",   # Dorado sangre
            "label_fg": "#FF4500",    # Rojo anaranjado
            "entry_bg": "#222222",    # Gris oscuro
            "entry_fg": "#FF0000",    # Rojo brillante
            "bg_color": "#111111",
            "action_btn_bg": "#450000",
            "action_btn_fg": "#FFA500",
            "delete_btn_bg": "#B22222",
            "music": "ultrakill_theme.mp3",
            "history_bg": "#111111",
            "history_fg": "#FF0000"
        },
        "sonic": {
            "type": "gradient",
            "colors": [(0, 100, 255), (0, 200, 255), (0, 50, 150)],
            "button_bg": "#0066CC",
            "button_fg": "#FFCC00",
            "label_fg": "#0066CC",
            "entry_bg": "#99CCFF",
            "entry_fg": "black",
            "bg_color": "#99CCFF",
            "action_btn_bg": "#3399FF",
            "action_btn_fg": "#003366",
            "delete_btn_bg": "#FF6600",
            "music": "sonic_theme.mp3",
            "history_bg": "#99CCFF",
            "history_fg": "#003366"
        },
        "zelda": {
            "type": "gradient",
            "colors": [(0, 100, 0), (150, 120, 50), (70, 40, 10)],
            "button_bg": "#4B692F",
            "button_fg": "#F5E296",
            "label_fg": "#4B692F",
            "entry_bg": "#E6D3A7",
            "entry_fg": "black",
            "bg_color": "#E6D3A7",
            "action_btn_bg": "#8A9A5B",
            "action_btn_fg": "#2C4001",
            "delete_btn_bg": "#8B4513",
            "music": "zelda_theme.mp3",
            "history_bg": "#E6D3A7",
            "history_fg": "#2C4001"
        },
        "mario": {
            "type": "gradient",
            "colors": [(200, 0, 0), (0, 0, 200), (255, 200, 0)],
            "button_bg": "#E52521",
            "button_fg": "#FBD000",
            "label_fg": "#E52521",
            "entry_bg": "#6BACE4",
            "entry_fg": "black",
            "bg_color": "#6BACE4",
            "action_btn_bg": "#FF6B6B",
            "action_btn_fg": "#8B0000",
            "delete_btn_bg": "#FF4500",
            "music": "mario_theme.mp3",
            "history_bg": "#6BACE4",
            "history_fg": "#8B0000"
        },
        "pokemon": {
            "type": "gradient",
            "colors": [(255, 203, 5), (61, 125, 202), (255, 0, 0)],
            "button_bg": "#FFCB05",
            "button_fg": "#3D7DCA",
            "label_fg": "#3D7DCA",
            "entry_bg": "#FFCB05",
            "entry_fg": "black",
            "bg_color": "#FFCB05",
            "action_btn_bg": "#3D7DCA",
            "action_btn_fg": "#FFCB05",
            "delete_btn_bg": "#FF0000",
            "music": "pokemon_theme.mp3",
            "history_bg": "#FFCB05",
            "history_fg": "#3D7DCA"
        },
        "minecraft": {
            "type": "gradient",
            "colors": [(0, 150, 0), (100, 50, 0), (0, 100, 150)],
            "button_bg": "#00A651",
            "button_fg": "#8B4513",
            "label_fg": "#00A651",
            "entry_bg": "#D2B48C",
            "entry_fg": "black",
            "bg_color": "#D2B48C",
            "action_btn_bg": "#8B4513",
            "action_btn_fg": "#00A651",
            "delete_btn_bg": "#CD5C5C",
            "music": "minecraft_theme.mp3",
            "history_bg": "#D2B48C",
            "history_fg": "#8B4513"
        }
    }
    return themes.get(theme_name, themes["default"])

#########################
# Clase principal
#########################
class PasswordManager:
    def __init__(self, root):
        self.root = root
        self.root.title("PassManager 🔒")
        self.root.geometry("800x600")
      
        # Inicializar add_btn
        self.add_btn = None

        # Estado de actualizaciones
        self.update_available = False

        # Inicializar pygame mixer
        pygame.mixer.init()
      
        # Cargar configuración de temas
        self.settings = self.load_settings()
        self.current_theme = self.settings.get("theme", "default")
        self.theme_colors = get_theme_colors(self.current_theme)
      
        # Estado global de la música
        self.music_enabled = self.settings.get("music_enabled", True)
        self.music_paused = self.settings.get("music_paused", False)
        self.volume_level = self.settings.get("volume", 0.03)
        self.current_music = None

        pygame.mixer.music.set_volume(self.volume_level)

        # Crear un frame contenedor principal
        self.container = tk.Frame(root)
        self.container.pack(fill="both", expand=True)
      
        # Canvas de fondo
        self.bg_canvas = tk.Canvas(self.container)
        self.bg_canvas.pack(fill="both", expand=True)
        self.bg_canvas.bind("<Configure>", self.draw_gradient)

        # Frame principal para la interfaz
        self.main_frame = tk.Frame(self.bg_canvas, bg=self.theme_colors["bg_color"])
        self.main_window = self.bg_canvas.create_window(
            (0, 0), 
            window=self.main_frame, 
            anchor="nw", 
            tags="main_window"
        )
      
        # Pedir o crear contraseña maestra
        if not os.path.exists(MASTER_FILE):
            if not self.create_master_password():
                self.root.destroy()
                return
        else:
            if not self.prompt_master_password():
                self.root.destroy()
                return

        # Carga la clave Fernet (se genera solo una vez)
        self.master_key = self.load_or_create_key()
        # Carga o inicializa datos
        self.data = self.load_data()
        # Para mostrar/ocultar contraseñas en cada entrada
        self.password_visible = {}

        # Construir UI principal
        self.build_main_ui()
      
        # Ajustar el frame principal cuando cambie el tamaño
        self.bg_canvas.bind("<Configure>", self.on_canvas_resize)
      
        # Iniciar música si corresponde
        self.init_music()
        
        # Verificar actualizaciones en segundo plano
        self.check_for_updates_in_background()
        
        # Mostrar cambios si es una nueva instalación
        self.show_update_changes_if_needed()

    def on_canvas_resize(self, event):
        """Ajusta el frame principal cuando cambia el tamaño del canvas"""
        self.bg_canvas.itemconfig("main_window", width=event.width)
        self.draw_gradient(event)

    #########################
    # Manejo de música
    #########################
    def init_music(self):
        pygame.mixer.music.set_volume(self.volume_level)
        if self.music_enabled:
            self.play_theme_music()
            if self.music_paused:
                self.pause_music()
  
    def play_theme_music(self):
        music_file = self.theme_colors.get("music")
        if not music_file:
            return
        try:
            music_path = get_music_path(music_file)
            if os.path.exists(music_path):
                pygame.mixer.music.set_volume(self.volume_level)
                pygame.mixer.music.load(music_path)
                pygame.mixer.music.play(-1)
                self.current_music = music_file
                self.music_paused = False
                self.settings["music_paused"] = False
                self.save_settings()
            else:
                print(f"Archivo de música no encontrado: {music_path}")
        except Exception as e:
            print(f"Error al reproducir música: {e}")
  
    def pause_music(self):
        if pygame.mixer.music.get_busy() and not self.music_paused:
            pygame.mixer.music.pause()
            self.music_paused = True
            self.settings["music_paused"] = True
            self.save_settings()
  
    def unpause_music(self):
        if self.music_paused and self.music_enabled:
            pygame.mixer.music.unpause()
            self.music_paused = False
            self.settings["music_paused"] = False
            self.save_settings()
  
    def stop_music(self):
        if pygame.mixer.music.get_busy() or self.music_paused:
            pygame.mixer.music.stop()
            self.music_paused = False
            self.settings["music_paused"] = False
            self.save_settings()
  
    def toggle_music(self):
        if self.music_enabled:
            if self.music_paused:
                self.unpause_music()
            else:
                self.pause_music()
  
    def change_music(self, music_file):
        self.stop_music()
        if music_file:
            try:
                music_path = get_music_path(music_file)
                if os.path.exists(music_path):
                    pygame.mixer.music.load(music_path)
                    pygame.mixer.music.play(-1)
                    self.current_music = music_file
                    self.music_paused = False
                    self.settings["music_paused"] = False
                    self.save_settings()
                else:
                    print(f"Archivo de música no encontrado: {music_path}")
            except Exception as e:
                print(f"Error al cambiar música: {e}")

    def set_volume(self, volume):
        self.volume_level = volume
        pygame.mixer.music.set_volume(volume)
        self.settings["volume"] = volume
        self.save_settings()

    def show_volume_control(self):
        win = tk.Toplevel(self.root)
        win.title("Control de Audio")
        win.geometry("300x150")
        win.transient(self.root)
        win.grab_set()
        win.config(bg=self.theme_colors["bg_color"])
      
        control_frame = tk.Frame(win, bg=self.theme_colors["bg_color"])
        control_frame.pack(pady=10, fill="x", padx=20)
      
        btn_frame = tk.Frame(control_frame, bg=self.theme_colors["bg_color"])
        btn_frame.pack(fill="x", pady=5)
      
        toggle_text = "⏸️ Pausar" if not self.music_paused else "▶️ Reanudar"
        toggle_btn = tk.Button(
            btn_frame, 
            text=toggle_text,
            command=self.toggle_music,
            bg=self.theme_colors["button_bg"],
            fg=self.theme_colors["button_fg"]
        )
        toggle_btn.pack(side="left", padx=5)
      
        stop_btn = tk.Button(
            btn_frame, 
            text="⏹️ Detener",
            command=self.stop_music,
            bg=self.theme_colors["button_bg"],
            fg=self.theme_colors["button_fg"]
        )
        stop_btn.pack(side="left", padx=5)
      
        volume_frame = tk.Frame(control_frame, bg=self.theme_colors["bg_color"])
        volume_frame.pack(fill="x", pady=5)
      
        volume_var = tk.DoubleVar(value=self.volume_level)
        volume_slider = tk.Scale(
            volume_frame,
            from_=0.0,
            to=1.0,
            resolution=0.01,
            orient="horizontal",
            variable=volume_var,
            command=lambda v: self.set_volume(float(v)),
            length=250,
            bg=self.theme_colors["bg_color"],
            fg=self.theme_colors["label_fg"],
            highlightthickness=0
        )
        volume_slider.pack()
      
        vol_label = tk.Label(
            volume_frame, 
            text=f"Volumen: {int(self.volume_level*100)}%",
            bg=self.theme_colors["bg_color"],
            fg=self.theme_colors["label_fg"]
        )
        vol_label.pack(pady=5)
      
        def update_label(*args):
            vol_label.config(text=f"Volumen: {int(volume_var.get()*100)}%")
        volume_var.trace_add("write", update_label)

    #########################
    # Manejo de configuración
    #########################
    def load_settings(self):
        settings = {}
        if os.path.exists(SETTINGS_FILE):
            try:
                with open(SETTINGS_FILE, "r") as f:
                    settings = json.load(f)
            except:
                pass
        return settings
  
    def save_settings(self):
        with open(SETTINGS_FILE, "w") as f:
            json.dump(self.settings, f)

    #########################
    # Manejo de contraseña maestra
    #########################
    def create_master_password(self):
        while True:
            pwd1 = simpledialog.askstring("Contraseña Maestra", "Crea una contraseña maestra:", show="*")
            if pwd1 is None:
                return False
            if not validate_password_strength(pwd1):
                messagebox.showerror("Error", "La contraseña debe tener al menos 8 caracteres, incluir letras y dígitos.")
                continue
            pwd2 = simpledialog.askstring("Confirmar Contraseña", "Confirma la contraseña maestra:", show="*")
            if pwd2 is None:
                return False
            if pwd1 != pwd2:
                messagebox.showerror("Error", "Las contraseñas no coinciden. Intenta de nuevo.")
                continue
            hashed = hash_master_password(pwd1)
            with open(MASTER_FILE, "wb") as f:
                f.write(hashed)
            messagebox.showinfo("Éxito", "Contraseña maestra creada correctamente.")
            return True

    def prompt_master_password(self):
        with open(MASTER_FILE, "rb") as f:
            stored = f.read()
        for _ in range(3):
            pwd = simpledialog.askstring("Contraseña Maestra", "Ingresa la contraseña maestra:", show="*")
            if pwd is None:
                return False
            if verify_master_password(pwd, stored):
                return True
            else:
                messagebox.showerror("Error", "Contraseña incorrecta.")
        messagebox.showerror("Error", "Fallaste 3 intentos. Saliendo.")
        return False

    #########################
    # Manejo de clave Fernet y datos cifrados
    #########################
    def load_or_create_key(self):
        if os.path.exists(KEY_FILE):
            with open(KEY_FILE, "rb") as f:
                return f.read()
        else:
            key = Fernet.generate_key()
            with open(KEY_FILE, "wb") as f:
                f.write(key)
            return key

    def encrypt_data(self, data):
        cipher = Fernet(self.master_key)
        json_data = json.dumps(data).encode()
        return cipher.encrypt(json_data)

    def decrypt_data(self, encrypted_data):
        cipher = Fernet(self.master_key)
        decrypted = cipher.decrypt(encrypted_data)
        return json.loads(decrypted.decode())

    def load_data(self):
        if not os.path.exists(DATA_FILE):
            return {}
        with open(DATA_FILE, "rb") as f:
            encrypted_data = f.read()
        try:
            return self.decrypt_data(encrypted_data)
        except:
            messagebox.showerror("Error", "No se pudo descifrar los datos.")
            return {}

    def save_data(self):
        encrypted_data = self.encrypt_data(self.data)
        with open(DATA_FILE, "wb") as f:
            f.write(encrypted_data)

    #########################
    # Dibujar fondo según tema
    #########################
    def draw_gradient(self, event=None):
        if not event:
            return
          
        self.bg_canvas.delete("gradient")
        width = event.width
        height = event.height
      
        theme = self.theme_colors
      
        if theme["type"] == "solid":
            color = theme.get("color", (40, 40, 40))
            hex_color = f"#{color[0]:02x}{color[1]:02x}{color[2]:02x}"
            self.bg_canvas.create_rectangle(0, 0, width, height, fill=hex_color, outline="", tags="gradient")
        else:
            colors = theme.get("colors", [(255, 182, 193), (230, 200, 255), (255, 255, 255)])
            steps = height if height > 0 else 1
            half = max(1, steps // 2)

            for i in range(steps):
                if i < half:
                    ratio = i / half
                    r = int(colors[0][0] + (colors[1][0] - colors[0][0]) * ratio)
                    g = int(colors[0][1] + (colors[1][1] - colors[0][1]) * ratio)
                    b = int(colors[0][2] + (colors[1][2] - colors[0][2]) * ratio)
                else:
                    ratio = (i - half) / half
                    r = int(colors[1][0] + (colors[2][0] - colors[1][0]) * ratio)
                    g = int(colors[1][1] + (colors[2][1] - colors[1][1]) * ratio)
                    b = int(colors[1][2] + (colors[2][2] - colors[1][2]) * ratio)
                color = f"#{r:02x}{g:02x}{b:02x}"
                y = i
                self.bg_canvas.create_line(0, y, width, y, fill=color, tags="gradient")

        self.bg_canvas.itemconfig("main_window", width=width, height=height)

    #########################
    # Interfaz Principal
    #########################
    def build_main_ui(self):
        self.current_screen = "main"
      
        if self.add_btn:
            self.add_btn.destroy()
            self.add_btn = None

        for widget in self.main_frame.winfo_children():
            widget.destroy()
      
        self.main_frame.config(bg=self.theme_colors["bg_color"])
      
        title = tk.Label(
            self.main_frame, 
            text="PassManager 🔒", 
            font=("Helvetica", 20, "bold"),
            fg=self.theme_colors["label_fg"],
            bg=self.theme_colors["bg_color"]
        )
        title.pack(pady=10)

        top_frame = tk.Frame(self.main_frame, bg=self.theme_colors["bg_color"])
        top_frame.pack(fill="x", pady=5)

        # Botón de volumen (altavoz)
        self.audio_btn = tk.Button(
            top_frame, 
            text="🔊",
            command=self.show_audio_menu,
            bg=self.theme_colors["button_bg"],
            fg=self.theme_colors["button_fg"],
            width=3,
            font=("Arial", 12)
        )
        self.audio_btn.pack(side="left", padx=2)

        # Botón de temas (brocha)
        self.theme_btn = tk.Button(
            top_frame, 
            text="🎨",
            command=self.show_theme_menu,
            bg=self.theme_colors["button_bg"],
            fg=self.theme_colors["button_fg"],
            width=3,
            font=("Arial", 12)
        )
        self.theme_btn.pack(side="left", padx=2)

        # Botón de actualización (se crea pero no se muestra todavía)
        self.update_btn = tk.Button(
            top_frame, 
            text="🔄",
            command=lambda: self.check_updates(True),
            bg=self.theme_colors["button_bg"],
            fg=self.theme_colors["button_fg"],
            width=3,
            font=("Arial", 12)
        )
        # Asegurarse de llamar a update_ui_for_updates
        self.update_ui_for_updates()

        search_var = tk.StringVar()
        search_entry = tk.Entry(top_frame, textvariable=search_var, width=30)
        search_entry.pack(side="left", padx=5, fill="x", expand=True)
        search_entry.insert(0, "Buscar sección...")
        search_entry.bind("<FocusIn>", lambda e: search_entry.delete(0, tk.END) if search_entry.get() == "Buscar sección..." else None)

        def on_search_sections(*args):
            term = search_var.get().lower().strip()
            self.show_section_list(filtered=term)
        search_var.trace_add("write", on_search_sections)

        # Botón de exportar CSV
        exp_btn = tk.Button(
            top_frame, 
            text="📤", 
            command=self.export_csv,
            bg=self.theme_colors["button_bg"],
            fg=self.theme_colors["button_fg"],
            width=3,
            font=("Arial", 12)
        )
        exp_btn.pack(side="left", padx=2)

        # Botón de importar CSV
        imp_btn = tk.Button(
            top_frame,
            text="📥",
            command=self.import_csv,
            bg=self.theme_colors["button_bg"],
            fg=self.theme_colors["button_fg"],
            width=3,
            font=("Arial", 12)
        )
        imp_btn.pack(side="left", padx=2)

        # Botón para agregar cuenta
        add_account_btn = tk.Button(
            top_frame,
            text="+",
            command=self.show_add_account_direct,
            bg=self.theme_colors["button_bg"],
            fg=self.theme_colors["button_fg"],
            width=3,
            height=1,
            font=("Arial", 14, "bold"),
            bd=1,
            relief="raised"
        )
        add_account_btn.pack(side="left", padx=2)

        list_frame = tk.Frame(self.main_frame, bg=self.theme_colors["bg_color"])
        list_frame.pack(fill="both", expand=True, pady=10)

        canvas = tk.Canvas(list_frame, highlightthickness=0, bg=self.theme_colors["bg_color"])
        scrollbar = tk.Scrollbar(list_frame, orient="vertical", command=canvas.yview)
        scroll_content = tk.Frame(canvas, bg=self.theme_colors["bg_color"])

        scroll_content.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scroll_content, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        self.section_scroll_content = scroll_content
        self.show_section_list()

    def update_ui_for_updates(self):
        """Actualiza la UI según la disponibilidad de actualizaciones"""
        if hasattr(self, 'update_btn'):
            if self.update_available:
                self.update_btn.pack(side="left", padx=2)
            else:
                self.update_btn.pack_forget()

    def show_audio_menu(self):
        """Muestra el menú de opciones de audio"""
        menu = tk.Menu(self.root, tearoff=0, 
                      bg=self.theme_colors["entry_bg"], 
                      fg=self.theme_colors["entry_fg"])
        
        menu.add_command(label="Activar música", command=self.enable_music)
        menu.add_command(label="Desactivar música", command=self.disable_music)
        menu.add_separator()
        menu.add_command(label="Pausar/Reanudar", command=self.toggle_music)
        menu.add_command(label="Detener música", command=self.stop_music)
        menu.add_separator()
        menu.add_command(label="Control de audio...", command=self.show_volume_control)
        
        # Mostrar el menú cerca del botón
        btn_x = self.audio_btn.winfo_rootx()
        btn_y = self.audio_btn.winfo_rooty() + self.audio_btn.winfo_height()
        menu.post(btn_x, btn_y)

    def show_theme_menu(self):
        """Muestra el menú de selección de temas"""
        menu = tk.Menu(self.root, tearoff=0, 
                      bg=self.theme_colors["entry_bg"], 
                      fg=self.theme_colors["entry_fg"])
        
        menu.add_command(label="Por defecto", command=lambda: self.change_theme("default"))
        menu.add_command(label="Modo Oscuro", command=lambda: self.change_theme("dark"))
        menu.add_command(label="Morado", command=lambda: self.change_theme("purple"))
        menu.add_separator()
        menu.add_command(label="Ultrakill", command=lambda: self.change_theme("ultrakill"))
        menu.add_command(label="Sonic", command=lambda: self.change_theme("sonic"))
        menu.add_command(label="Zelda", command=lambda: self.change_theme("zelda"))
        menu.add_command(label="Mario", command=lambda: self.change_theme("mario"))
        menu.add_command(label="Pokémon", command=lambda: self.change_theme("pokemon"))
        menu.add_command(label="Minecraft", command=lambda: self.change_theme("minecraft"))
        
        # Mostrar el menú cerca del botón
        btn_x = self.theme_btn.winfo_rootx()
        btn_y = self.theme_btn.winfo_rooty() + self.theme_btn.winfo_height()
        menu.post(btn_x, btn_y)

    def show_add_account_direct(self):
        """Muestra diálogo para agregar cuenta sin elegir sección primero."""
        if not self.data:
            messagebox.showinfo("Información", "Primero debes crear una sección.")
            return
        self.add_account()

    def show_section_list(self, filtered: str = ""):
        for widget in self.section_scroll_content.winfo_children():
            widget.destroy()

        if not self.data:
            tk.Label(
                self.section_scroll_content, 
                text="No hay secciones creadas.", 
                font=("Helvetica", 12),
                fg=self.theme_colors["label_fg"],
                bg=self.theme_colors["bg_color"]
            ).pack(pady=10)
            return

        for section in sorted(self.data.keys()):
            if filtered and filtered not in section.lower():
                continue
            count = len(self.data[section])
            frame = tk.Frame(self.section_scroll_content, bg=self.theme_colors["bg_color"])
            frame.pack(fill="x", pady=5, ipady=5)

            section_text = f"{count} • {section}"
            btn = tk.Button(
                frame, 
                text=section_text, 
                command=lambda s=section: self.show_section(s),
                bg=self.theme_colors["button_bg"],
                fg=self.theme_colors["button_fg"]
            )
            btn.pack(side="left", fill="x", expand=True)

            del_btn = tk.Button(
                frame, 
                text="❌", 
                width=3, 
                command=lambda s=section: self.delete_section(s),
                bg=self.theme_colors["delete_btn_bg"],
                fg="white"
            )
            del_btn.pack(side="right", padx=5)

    def show_section(self, section: str):
        self.current_screen = "section"
        self.current_section = section
      
        if self.add_btn:
            self.add_btn.destroy()
            self.add_btn = None

        for widget in self.main_frame.winfo_children():
            widget.destroy()
      
        title_frame = tk.Frame(self.main_frame, bg=self.theme_colors["bg_color"])
        title_frame.pack(fill="x", pady=5)

        back_btn = tk.Button(
            title_frame, 
            text="← Volver", 
            command=self.build_main_ui,
            bg=self.theme_colors["button_bg"],
            fg=self.theme_colors["button_fg"]
        )
        back_btn.pack(side="left")

        title = tk.Label(
            title_frame, 
            text=f"Sección: {section}", 
            font=("Helvetica", 18, "bold"),
            fg=self.theme_colors["label_fg"],
            bg=self.theme_colors["bg_color"]
        )
        title.pack(side="left", padx=10)

        search_var = tk.StringVar()
        search_entry = tk.Entry(
            self.main_frame, 
            textvariable=search_var, 
            width=30,
            bg=self.theme_colors["entry_bg"],
            fg=self.theme_colors["entry_fg"]
        )
        search_entry.pack(pady=5)
        search_entry.insert(0, "Buscar correo...")
        search_entry.bind("<FocusIn>", lambda e: search_entry.delete(0, tk.END) if search_entry.get() == "Buscar correo..." else None)

        def on_search_accounts(*args):
            term = search_var.get().lower().strip()
            self.show_account_list(section, filtered=term)
        search_var.trace_add("write", on_search_accounts)

        list_frame = tk.Frame(self.main_frame, bg=self.theme_colors["bg_color"])
        list_frame.pack(fill="both", expand=True, pady=10)

        canvas = tk.Canvas(list_frame, highlightthickness=0, bg=self.theme_colors["bg_color"])
        scrollbar = tk.Scrollbar(list_frame, orient="vertical", command=canvas.yview)
        scroll_content = tk.Frame(canvas, bg=self.theme_colors["bg_color"])

        scroll_content.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scroll_content, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        self.account_scroll_content = scroll_content
        self.show_account_list(section)

        add_btn = tk.Button(
            self.main_frame, 
            text="Agregar Cuenta", 
            command=lambda: self.add_account(section),
            bg=self.theme_colors["button_bg"],
            fg=self.theme_colors["button_fg"]
        )
        add_btn.pack(pady=5)

    def show_account_list(self, section: str, filtered: str = ""):
        for widget in self.account_scroll_content.winfo_children():
            widget.destroy()

        entries = self.data.get(section, [])
        if not entries:
            tk.Label(
                self.account_scroll_content, 
                text="No hay cuentas en esta sección.", 
                font=("Helvetica", 12),
                fg=self.theme_colors["label_fg"],
                bg=self.theme_colors["bg_color"]
            ).pack(pady=10)
            return

        for i, entry in enumerate(entries):
            email = entry["email"]
            if filtered and filtered not in email.lower():
                continue

            entry_frame = tk.Frame(
                self.account_scroll_content, 
                bg=self.theme_colors["bg_color"]
            )
            entry_frame.pack(fill="x", pady=5, ipady=5)

            account_type = entry.get("account_type", "")
            if account_type:
                type_label = tk.Label(
                    entry_frame,
                    text=f"{account_type}:",
                    width=15,
                    anchor="w",
                    bg=self.theme_colors["entry_bg"],
                    fg=self.theme_colors["entry_fg"],
                    relief="solid",
                    bd=1
                )
                type_label.pack(side="left", padx=2)

            email_label = tk.Label(
                entry_frame,
                    text=email,
                    width=30,
                    anchor="w",
                    bg=self.theme_colors["entry_bg"],
                    fg=self.theme_colors["entry_fg"],
                    relief="solid",
                    bd=1
                )
            email_label.pack(side="left", padx=2)

            pwd = entry["password"]
            password_var = tk.StringVar(value="*" * len(pwd))
            eid = f"{section}_{i}"
            self.password_visible[eid] = False

            password_entry = tk.Entry(
                entry_frame,
                textvariable=password_var,
                width=25,
                state="disabled",
                relief="solid",
                bd=1,
                disabledbackground=self.theme_colors["entry_bg"],
                disabledforeground=self.theme_colors["entry_fg"]
            )
            password_entry.pack(side="left", padx=2)

            def toggle(eid=eid, var=password_var, real=pwd):
                self.password_visible[eid] = not self.password_visible[eid]
                var.set(real if self.password_visible[eid] else "*" * len(real))
            eye_btn = tk.Button(
                entry_frame,
                text="👁",
                command=toggle,
                bg=self.theme_colors["action_btn_bg"],
                fg=self.theme_colors["action_btn_fg"]
            )
            eye_btn.pack(side="left", padx=4)

            def copy_pwd(p=pwd):
                self.copy_to_clipboard(p)
            copy_btn = tk.Button(
                entry_frame,
                text="📋",
                command=copy_pwd,
                bg=self.theme_colors["action_btn_bg"],
                fg=self.theme_colors["action_btn_fg"]
            )
            copy_btn.pack(side="left", padx=4)

            edit_btn = tk.Button(
                entry_frame,
                text="✏️",
                command=lambda s=section, idx=i: self.edit_account(s, idx),
                bg=self.theme_colors["action_btn_bg"],
                fg=self.theme_colors["action_btn_fg"]
            )
            edit_btn.pack(side="left", padx=4)

            hist_btn = tk.Button(
                entry_frame,
                text="📜",
                command=lambda s=section, idx=i: self.view_history(s, idx),
                bg=self.theme_colors["action_btn_bg"],
                fg=self.theme_colors["action_btn_fg"]
            )
            hist_btn.pack(side="left", padx=4)

            del_btn = tk.Button(
                entry_frame,
                text="🗑",
                command=lambda s=section, idx=i: self.delete_account(s, idx),
                bg=self.theme_colors["delete_btn_bg"],
                fg="white"
            )
            del_btn.pack(side="left", padx=4)

    #########################
    # Operaciones CRUD
    #########################
    def copy_to_clipboard(self, text: str):
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        messagebox.showinfo("Copiado", "Contraseña copiada al portapapeles.")

    def show_add_options(self):
        menu = tk.Toplevel(self.root)
        menu.title("Opciones")
        menu.geometry("250x150")
        menu.transient(self.root)
        menu.grab_set()
        menu.config(bg=self.theme_colors["bg_color"])

        tk.Button(
            menu, 
            text="Agregar Sección", 
            command=lambda: [menu.destroy(), self.add_section()],
            bg=self.theme_colors["button_bg"],
            fg=self.theme_colors["button_fg"]
        ).pack(pady=10, fill="x", padx=20)
      
        tk.Button(
            menu, 
            text="Agregar Cuenta", 
            command=lambda: [menu.destroy(), self.add_account()],
            bg=self.theme_colors["button_bg"],
            fg=self.theme_colors["button_fg"]
        ).pack(pady=10, fill="x", padx=20)

    def add_section(self):
        name = simpledialog.askstring("Nueva Sección", "Nombre de la sección:")
        if not name:
            return
        if name in self.data:
            messagebox.showerror("Error", "La sección ya existe.")
            return
        self.data[name] = []
        self.save_data()
        messagebox.showinfo("Éxito", f"Sección '{name}' creada.")
        self.build_main_ui()

    def delete_section(self, section: str):
        if messagebox.askyesno("Confirmar", f"¿Eliminar la sección '{section}' y todas sus cuentas?"):
            del self.data[section]
            self.save_data()
            self.build_main_ui()

    def add_account(self, section: str = None):
        if not self.data:
            messagebox.showinfo("Información", "Primero debes crear una sección.")
            return

        win = tk.Toplevel(self.root)
        win.title("Agregar Cuenta")
        win.geometry("350x420")
        win.transient(self.root)
        win.grab_set()
        win.config(bg=self.theme_colors["bg_color"])

        if section is None:
            tk.Label(
                win, 
                text="Selecciona la sección:",
                fg=self.theme_colors["label_fg"],
                bg=self.theme_colors["bg_color"]
            ).pack(pady=5)
            selected = tk.StringVar(win)
            dropdown = ttk.Combobox(win, textvariable=selected, values=list(self.data.keys()), state="readonly")
            dropdown.pack(pady=5)
            dropdown.current(0)
        else:
            selected = tk.StringVar(value=section)

        account_type_var = tk.StringVar()
        email_var = tk.StringVar()
        pass_var = tk.StringVar()
        show_pwd_var = tk.BooleanVar(value=False)

        tk.Label(
            win, 
            text="De qué es la cuenta:",
            fg=self.theme_colors["label_fg"],
            bg=self.theme_colors["bg_color"]
            ).pack(pady=5)
        account_type_entry = tk.Entry(
            win,
            textvariable=account_type_var,
            width=30,
            bg=self.theme_colors["entry_bg"],
            fg=self.theme_colors["entry_fg"]
        )
        account_type_entry.pack(pady=5)

        tk.Label(
            win, 
            text="Correo electrónico:",
            fg=self.theme_colors["label_fg"],
            bg=self.theme_colors["bg_color"]
            ).pack(pady=5)
        email_entry = tk.Entry(
            win, 
            textvariable=email_var, 
            width=30,
            bg=self.theme_colors["entry_bg"],
            fg=self.theme_colors["entry_fg"]
        )
        email_entry.pack(pady=5)

        tk.Label(
            win, 
            text="Contraseña:",
            fg=self.theme_colors["label_fg"],
            bg=self.theme_colors["bg_color"]
        ).pack(pady=5)
        pw_frame = tk.Frame(win, bg=self.theme_colors["bg_color"])
        pw_frame.pack(pady=5)
        pw_entry = tk.Entry(
            pw_frame, 
            textvariable=pass_var, 
            width=25, 
            show="*",
            bg=self.theme_colors["entry_bg"],
            fg=self.theme_colors["entry_fg"]
        )
        pw_entry.pack(side="left", padx=2)

        def toggle_show():
            pw_entry.config(show="" if show_pwd_var.get() else "*")
        show_chk = tk.Checkbutton(
            win, 
            text="Mostrar contraseña", 
            variable=show_pwd_var, 
            command=toggle_show,
            fg=self.theme_colors["label_fg"],
            bg=self.theme_colors["bg_color"]
        )
        show_chk.pack()

        gen_btn = tk.Button(
            pw_frame, 
            text="🎲",
            command=lambda: pass_var.set(generate_random_password()),
            bg=self.theme_colors["button_bg"],
            fg=self.theme_colors["button_fg"]
        )
        gen_btn.pack(side="left", padx=2)

        def save():
            account_type = account_type_var.get().strip()
            email = email_var.get().strip()
            password = pass_var.get().strip()
            sec = selected.get()

            if not email or not password or not account_type:
                messagebox.showerror("Error", "Datos incompletos. Debes ingresar 'de qué es la cuenta', correo y contraseña.")
                return
            if not validate_password_strength(password):
                messagebox.showerror("Error", "La contraseña debe tener al menos 8 caracteres, incluir letras y dígitos.")
                return

            entry = {"account_type": account_type, "email": email, "password": password, "history": []}
            self.data[sec].append(entry)
            self.save_data()
            messagebox.showinfo("Éxito", "Cuenta guardada.")
            win.destroy()
            if section:
                self.show_section(section)
            else:
                self.build_main_ui()

        tk.Button(
            win, 
            text="Guardar", 
            command=save,
            bg=self.theme_colors["button_bg"],
            fg=self.theme_colors["button_fg"]
        ).pack(pady=10)

    def delete_account(self, section: str, index: int):
        if messagebox.askyesno("Confirmar", "¿Eliminar esta cuenta?"):
            del self.data[section][index]
            self.save_data()
            self.show_section(section)

    def edit_account(self, section: str, index: int):
        entry = self.data[section][index]
        entry.setdefault("history", [])

        win = tk.Toplevel(self.root)
        win.title("Editar Cuenta")
        win.geometry("350x420")
        win.transient(self.root)
        win.grab_set()
        win.config(bg=self.theme_colors["bg_color"])

        account_type_var = tk.StringVar(value=entry.get("account_type", ""))
        email_var = tk.StringVar(value=entry['email'])
        pass_var = tk.StringVar(value=entry['password'])
        show_pwd_var = tk.BooleanVar(value=False)

        tk.Label(
            win, 
            text="De qué es la cuenta:",
            fg=self.theme_colors["label_fg"],
            bg=self.theme_colors["bg_color"]
        ).pack(pady=5)
        account_type_entry = tk.Entry(
            win,
            textvariable=account_type_var,
            width=30,
            bg=self.theme_colors["entry_bg"],
            fg=self.theme_colors["entry_fg"]
        )
        account_type_entry.pack(pady=5)

        tk.Label(
            win, 
            text="Correo electrónico:",
            fg=self.theme_colors["label_fg"],
            bg=self.theme_colors["bg_color"]
        ).pack(pady=5)
        email_entry = tk.Entry(
            win, 
            textvariable=email_var, 
            width=30,
            bg=self.theme_colors["entry_bg"],
            fg=self.theme_colors["entry_fg"]
        )
        email_entry.pack(pady=5)

        tk.Label(
            win, 
            text="Contraseña:",
            fg=self.theme_colors["label_fg"],
            bg=self.theme_colors["bg_color"]
        ).pack(pady=5)
        pw_frame = tk.Frame(win, bg=self.theme_colors["bg_color"])
        pw_frame.pack(pady=5)
        pw_entry = tk.Entry(
            pw_frame, 
            textvariable=pass_var, 
            width=25, 
            show="*",
            bg=self.theme_colors["entry_bg"],
            fg=self.theme_colors["entry_fg"]
        )
        pw_entry.pack(side="left", padx=2)

        def toggle_show_edit():
            pw_entry.config(show="" if show_pwd_var.get() else "*")
        show_chk = tk.Checkbutton(
            win, 
            text="Mostrar contraseña", 
            variable=show_pwd_var, 
            command=toggle_show_edit,
            fg=self.theme_colors["label_fg"],
            bg=self.theme_colors["bg_color"]
        )
        show_chk.pack()

        gen_btn = tk.Button(
            pw_frame, 
            text="🎲",
            command=lambda: pass_var.set(generate_random_password()),
            bg=self.theme_colors["button_bg"],
            fg=self.theme_colors["button_fg"]
        )
        gen_btn.pack(side="left", padx=2)

        def save():
            new_account_type = account_type_var.get().strip()
            new_email = email_var.get().strip()
            new_pwd = pass_var.get().strip()
            if not new_account_type or not new_email or not new_pwd:
                messagebox.showerror("Error", "Datos incompletos.")
                return
            if not validate_password_strength(new_pwd):
                messagebox.showerror("Error", "La contraseña debe tener al menos 8 caracteres, incluir letras y dígitos.")
                return

            if new_pwd != entry["password"]:
                old = entry["password"]
                entry["history"].append({
                    "password": old,
                    "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                })

            entry["account_type"] = new_account_type
            entry["email"] = new_email
            entry["password"] = new_pwd
            self.data[section][index] = entry
            self.save_data()
            win.destroy()
            self.show_section(section)

        tk.Button(
            win, 
            text="Guardar Cambios", 
            command=save,
            bg=self.theme_colors["button_bg"],
            fg=self.theme_colors["button_fg"]
        ).pack(pady=10)

    def view_history(self, section: str, index: int):
        entry = self.data[section][index]
        history = entry.get("history", [])

        win = tk.Toplevel(self.root)
        win.title(f"Historial: {entry['email']}")
        win.geometry("400x300")
        win.transient(self.root)
        win.grab_set()
        win.config(bg=self.theme_colors["history_bg"])

        if not history:
            tk.Label(
                win, 
                text="No hay historial de contraseñas.", 
                font=("Helvetica", 12),
                fg=self.theme_colors["history_fg"],
                bg=self.theme_colors["history_bg"]
            ).pack(pady=20)
            return

        frame = tk.Frame(win, bg=self.theme_colors["history_bg"])
        frame.pack(fill="both", expand=True, pady=10)

        style = ttk.Style()
        style.configure("Treeview", 
                        background=self.theme_colors["entry_bg"],
                        fieldbackground=self.theme_colors["entry_bg"],
                        foreground=self.theme_colors["entry_fg"])
        style.configure("Treeview.Heading", 
                        background=self.theme_colors["button_bg"],
                        foreground=self.theme_colors["button_fg"])

        cols = ("Fecha", "Contraseña Antigua")
        tree = ttk.Treeview(frame, columns=cols, show="headings")
        for col in cols:
            tree.heading(col, text=col)
            tree.column(col, anchor="center")

        for item in history:
            tree.insert("", tk.END, values=(item["date"], item["password"]))

        vsb = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=vsb.set)
        tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")

    #########################
    # Importar / Exportar CSV
    #########################
    def export_csv(self):
        file_path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files", "*.csv")])
        if not file_path:
            return
        try:
            with open(file_path, mode="w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(["Sección", "Email", "Contraseña", "De qué es la cuenta"])
                for section, entries in self.data.items():
                    for entry in entries:
                        writer.writerow([section, entry["email"], entry["password"], entry.get("account_type", "")])
            messagebox.showinfo("Exportar CSV", f"Datos exportados a {file_path}")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo exportar CSV.\n{e}")

    def import_csv(self):
        file_path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
        if not file_path:
            return
      
        section_win = tk.Toplevel(self.root)
        section_win.title("Seleccionar Sección")
        section_win.geometry("350x200")
        section_win.transient(self.root)
        section_win.grab_set()
        section_win.config(bg=self.theme_colors["bg_color"])
      
        tk.Label(
            section_win, 
            text="¿En qué sección quieres guardar las cuentas?",
            font=("Helvetica", 12),
            fg=self.theme_colors["label_fg"],
            bg=self.theme_colors["bg_color"]
        ).pack(pady=10)
      
        options_frame = tk.Frame(section_win, bg=self.theme_colors["bg_color"])
        options_frame.pack(pady=10, fill="x", padx=20)
      
        radio_var = tk.IntVar(value=0)
      
        tk.Radiobutton(
            options_frame, 
            text="Usar sección existente:",
            variable=radio_var,
            value=0,
            bg=self.theme_colors["bg_color"],
            fg=self.theme_colors["label_fg"]
        ).pack(anchor="w")
      
        sections = list(self.data.keys())
        selected_section = tk.StringVar(value=sections[0] if sections else "")
        section_dropdown = ttk.Combobox(
            options_frame, 
            textvariable=selected_section, 
            values=sections,
            state="readonly" if sections else "disabled"
        )
        section_dropdown.pack(fill="x", padx=30, pady=5)
      
        tk.Radiobutton(
            options_frame, 
            text="Crear nueva sección:",
            variable=radio_var,
            value=1,
            bg=self.theme_colors["bg_color"],
            fg=self.theme_colors["label_fg"]
        ).pack(anchor="w", pady=(10, 0))
      
        new_section_var = tk.StringVar()
        new_section_entry = tk.Entry(
            options_frame, 
            textvariable=new_section_var,
            bg=self.theme_colors["entry_bg"],
            fg=self.theme_colors["entry_fg"]
        )
        new_section_entry.pack(fill="x", padx=30, pady=5)
      
        def proceed():
            if radio_var.get() == 0:
                if section_dropdown['state'] == "disabled":
                    messagebox.showerror("Error", "No hay secciones existentes. Crea una nueva sección.")
                    return
                section_name = selected_section.get()
            else:
                section_name = new_section_var.get().strip()
                if not section_name:
                    messagebox.showerror("Error", "Debes ingresar un nombre para la nueva sección.")
                    return
                if section_name in self.data:
                    messagebox.showerror("Error", "La sección ya existe.")
                    return
                self.data[section_name] = []
          
            section_win.destroy()
            self.process_csv_import(file_path, section_name)
      
        tk.Button(
            section_win, 
            text="Continuar", 
            command=proceed,
            bg=self.theme_colors["button_bg"],
            fg=self.theme_colors["button_fg"]
        ).pack(pady=10)

    def process_csv_import(self, file_path: str, section: str):
        try:
            with open(file_path, mode="r", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                count_imported = 0
                for row in reader:
                    # Soporte para formato Brave: name,url,username,password,note
                    if "username" in row and "password" in row and "name" in row:
                        email = row.get("username", "").strip()
                        pwd = row.get("password", "").strip()
                        account_type = row.get("name", "").strip()
                    else:
                        email = row.get("Email", "").strip()
                        pwd = row.get("Contraseña", "").strip()
                        account_type = row.get("De qué es la cuenta", "").strip() if "De qué es la cuenta" in row else ""

                    if not email or not pwd:
                        continue

                    # Agregar sin filtrar duplicados ni validar fuerza
                    self.data[section].append({
                        "account_type": account_type,
                        "email": email,
                        "password": pwd,
                        "history": []
                    })
                    count_imported += 1

            self.save_data()
            messagebox.showinfo(
                "Importar CSV",
                f"Se importaron {count_imported} cuentas en la sección '{section}'."
            )
            self.build_main_ui()

        except Exception as e:
            messagebox.showerror("Error", f"No se pudo importar CSV.\n{e}")

    #########################
    # Cambio de temas
    #########################
    def change_theme(self, theme_name):
        self.current_theme = theme_name
        self.theme_colors = get_theme_colors(theme_name)
        self.settings["theme"] = theme_name
        self.save_settings()
      
        self.draw_gradient()
      
        if self.add_btn:
            self.add_btn.config(
                bg=self.theme_colors["button_bg"],
                fg=self.theme_colors["button_fg"],
                activebackground=self.theme_colors["button_bg"],
                activeforeground=self.theme_colors["button_fg"]
            )
      
        self.main_frame.config(bg=self.theme_colors["bg_color"])

        new_music = self.theme_colors.get("music")
      
        if new_music and self.music_enabled:
            self.change_music(new_music)
        else:
            self.stop_music()
  
        if hasattr(self, 'current_screen') and self.current_screen == "section":
            self.show_section(self.current_section)
        else:
            self.build_main_ui()
          
    def toggle_music_state(self, enable):
        self.music_enabled = enable
        self.settings["music_enabled"] = enable
        self.save_settings()
      
        if enable:
            self.play_theme_music()
        else:
            self.stop_music()

    def enable_music(self):
        self.toggle_music_state(True)

    def disable_music(self):
        self.toggle_music_state(False)

    #########################
    # Actualizaciones automáticas
    #########################
    def get_current_version(self):
        """Obtiene la versión actual de la aplicación"""
        try:
            if os.path.exists(VERSION_FILE):
                with open(VERSION_FILE, "r") as f:
                    return f.read().strip()
        except:
            pass
        return "1.4.12"  # Versión por defecto si no se encuentra el archivo

    def save_current_version(self, version):
        """Guarda la versión actual en un archivo"""
        try:
            with open(VERSION_FILE, "w") as f:
                f.write(version)
        except:
            pass

    def check_for_updates_in_background(self):
        """Verifica actualizaciones en segundo plano"""
        threading.Thread(target=lambda: self.check_updates(False), daemon=True).start()

    def check_updates(self, show_message=False):
        """Verifica si hay actualizaciones disponibles en GitHub"""
        try:
            # Obtener versión actual
            current_version = self.get_current_version()
            
            # Obtener versión remota
            response = urllib.request.urlopen(GITHUB_REPO, timeout=5)
            remote_version = response.read().decode().strip()
            
            # Comparar versiones
            if remote_version != current_version:
                self.update_available = True
                if show_message:
                    self.root.after(0, lambda: self.show_update_prompt(remote_version, current_version))
                # Actualizar la UI siempre que haya actualización
                self.root.after(0, self.update_ui_for_updates)
            else:
                self.update_available = False
                if show_message:
                    self.root.after(0, lambda: messagebox.showinfo(
                        "Actualización", 
                        "Ya tienes la última versión."
                    ))
                # Actualizar la UI siempre
                self.root.after(0, self.update_ui_for_updates)
        except Exception as e:
            self.update_available = False
            if show_message:
                self.root.after(0, lambda: messagebox.showerror(
                    "Error", 
                    f"No se pudo verificar actualizaciones: {str(e)}"
                ))
            # Actualizar la UI siempre
            self.root.after(0, self.update_ui_for_updates)

    def download_changelog(self):
        """Descarga el changelog desde GitHub"""
        try:
            with urllib.request.urlopen(GITHUB_CHANGELOG, timeout=5) as response:
                return response.read().decode('utf-8')
        except Exception as e:
            print(f"Error al descargar changelog: {e}")
            return "No se pudieron obtener las notas de la versión."

    def show_changelog_dialog(self, changelog, version):
        """Muestra un diálogo con los cambios de la versión"""
        win = tk.Toplevel(self.root)
        win.title(f"Notas de la versión {version}")
        win.geometry("600x400")
        win.transient(self.root)
        win.grab_set()
        
        # Frame principal
        frame = tk.Frame(win)
        frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Área de texto para mostrar el changelog
        text = tk.Text(frame, wrap="word", font=("Arial", 10))
        scrollbar = tk.Scrollbar(frame, command=text.yview)
        text.configure(yscrollcommand=scrollbar.set)
        
        scrollbar.pack(side="right", fill="y")
        text.pack(side="left", fill="both", expand=True)
        
        # OJO: Usar "1.0" en lugar de la version de la app
        text.insert("1.0", changelog)
        text.config(state="disabled")
        
        # Botón para continuar
        tk.Button(
            win, 
            text="Continuar", 
            command=win.destroy,
            bg=self.theme_colors["button_bg"],
            fg=self.theme_colors["button_fg"]
        ).pack(pady=10)

    def show_update_prompt(self, remote_version, current_version):
        """Muestra un diálogo informando sobre la nueva versión"""
        # Descargar changelog
        changelog = self.download_changelog()
        
        # Mostrar diálogo con las notas primero
        self.show_changelog_dialog(changelog, remote_version)
        
        # Preguntar si desea actualizar
        if messagebox.askyesno(
            "Actualización disponible",
            f"¡Hay una nueva versión disponible!\n\n"
            f"Versión actual: {current_version}\n"
            f"Nueva versión: {remote_version}\n\n"
            "¿Deseas actualizar ahora?"
        ):
            self.perform_update(remote_version)

    def perform_update(self, remote_version):
        """Realiza el proceso de actualización"""
        # Guardar el changelog para mostrarlo después de la actualización
        try:
            changelog = self.download_changelog()
            with open(CHANGELOG_FILE, "w", encoding="utf-8") as f:
                f.write(remote_version + "\n\n" + changelog)
        except:
            pass
        
        # Para Windows: abrir el instalador
        if sys.platform == "win32":
            try:
                # Descargar el instalador
                temp_dir = tempfile.gettempdir()
                installer_path = os.path.join(temp_dir, "PassManager Updater.exe")
                
                # Descargar el archivo de actualización
                with urllib.request.urlopen("https://github.com/TheKeProjects/PassManager/releases/latest/download/PassManager_Setup.exe") as response:
                    with open(installer_path, 'wb') as out_file:
                        out_file.write(response.read())
                
                # Ejecutar el instalador
                subprocess.Popen([installer_path, "/SILENT"])
                
                # Salir de la aplicación
                self.exit_app()
            except Exception as e:
                messagebox.showerror("Error de actualización", 
                                    f"No se pudo descargar el actualizador: {str(e)}\n"
                                    "Por favor, actualiza manualmente desde GitHub.")
                webbrowser.open(UPDATE_URL)
        else:
            # Para otros sistemas, abrir la página de descargas
            webbrowser.open(UPDATE_URL)
            messagebox.showinfo(
                "Actualización manual",
                "Por favor, descarga la última versión desde el navegador."
            )

    def show_update_changes_if_needed(self):
        """Muestra los cambios si se acaba de actualizar"""
        if os.path.exists(CHANGELOG_FILE):
            try:
                with open(CHANGELOG_FILE, "r", encoding="utf-8") as f:
                    content = f.read()
                    # Separar versión y changelog
                    parts = content.split("\n\n", 1)
                    version = parts[0]
                    changelog = parts[1] if len(parts) > 1 else "No hay notas disponibles."
                
                # Mostrar diálogo con los cambios
                self.show_changelog_dialog(changelog, version)
                
                # Eliminar el archivo después de mostrarlo
                os.remove(CHANGELOG_FILE)
            except Exception as e:
                print(f"Error al mostrar cambios de actualización: {e}")

    #########################
    # Salir de la aplicación
    #########################
    def exit_app(self):
        self.save_data()
        self.stop_music()
        pygame.mixer.quit()
        self.root.quit()

#########################
# Ejecución
#########################
if __name__ == "__main__":
    root = tk.Tk()
    app = PasswordManager(root)
    root.protocol("WM_DELETE_WINDOW", app.exit_app)
    root.mainloop()